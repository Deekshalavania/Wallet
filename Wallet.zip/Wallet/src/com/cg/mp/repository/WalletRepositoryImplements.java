package com.cg.mp.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;

public class WalletRepositoryImplements implements IWalletRepository{

	Map<String,Customer> hm=new HashMap<>();
	List<Customer> list=new ArrayList<>();
	List<Customer> list2=new ArrayList<>();

	Customer c=new Customer();
	@Override
	public boolean save(Customer c) {
		if(hm.containsKey(c.getPhoneNum()))
		{
			return false;
		}
		else 
		{
			hm.put(c.getPhoneNum(),c);
			return true;
		}

	}

	@Override
	public List<Customer> findByPhone(String phoneNum) {
		// TODO Auto-generated method stub
     
		if(hm.containsKey(c.getPhoneNum()))
		{
			list2= (List)hm.get(c.getPhoneNum());
		}
		return list2;

	}

}