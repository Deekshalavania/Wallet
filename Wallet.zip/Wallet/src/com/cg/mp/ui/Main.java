package com.cg.mp.ui;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.bean.Wallet;
import com.cg.mp.service.WalletServiceImplements;

public class Main {
	
	WalletServiceImplements wallserv=new WalletServiceImplements();
	
	public static void main(String[] args) {
    Map<String,Customer> hm=new HashMap<>();
	hm.put("7568906432", new Customer("deeksha","7568906432",new Wallet(1,BigDecimal.valueOf(457477.7966))));
	hm.put("8863906432", new Customer("Neha","8863906432",new Wallet(2,BigDecimal.valueOf(800000.98886))));
	hm.put("7101906432", new Customer("Taneesha","7101906432",new Wallet(3,BigDecimal.valueOf(67487.1236))));
	hm.put("9538000411", new Customer("Shivi","9538000411",new Wallet(4,BigDecimal.valueOf(98765.0642))));
		
		System.out.println(wallserv.showBalance("7101906432"));

	}

}
