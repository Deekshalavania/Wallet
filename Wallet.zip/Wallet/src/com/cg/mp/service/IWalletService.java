package com.cg.mp.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;

public interface IWalletService {
	 
	Customer createAccount( String custName, String phoneNum, BigDecimal balance );
	List<Customer> showBalance(String phoneNum);

}
