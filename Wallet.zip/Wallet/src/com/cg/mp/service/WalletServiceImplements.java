package com.cg.mp.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.cg.mp.bean.Customer;
import com.cg.mp.repository.WalletRepositoryImplements;

public class WalletServiceImplements implements IWalletService {
	
	Customer c=new Customer();
	WalletRepositoryImplements repo=new WalletRepositoryImplements();

	@Override
	public Customer createAccount(String custName, String phoneNum, BigDecimal balance)
	{
		repo.save(c);
		return c;
		
	}

	@Override
	public List<Customer> showBalance(String phoneNum) 
	{
	  return repo.findByPhone(phoneNum);
	
		
	}
	

}
